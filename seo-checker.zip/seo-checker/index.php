<style type="text/css">
.title {
}
</style>
<center>
    <div class="enter_url" style="height:50px;width:70%;margin-top:50px;">
    
    <input type="text" placeholder="Website URL" size="45" style="height:30px;width:70%;" pattern="https://.*" required>

<button value="Analyise" style="background-color:skyblue;height:30px;">Analyise</button>
    </div>

    <?php
include 'title-tag.php';
include 'meta-description.php' 
?>

    
<br/>
</center>


<!--
<form method="post">		
		
		<label for="url">Enter an https:// URL:</label>

<input type="url" name="web"
       placeholder="https://example.com"
       pattern="https://.*" size="300"
       required>
	   
	   <button formaction="result.php">Title Description</button>
<button formaction="tagchecker.php">Tag Checker</button>
	   
</form>
        -->